module.exports=[27572,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function({children:a}){return(0,b.jsx)("html",{lang:"en",children:(0,b.jsx)("body",{children:a})})},"metadata",0,{title:"WhyNotDev - Software Studio",description:"Dynamic website and client portal for WhyNotDev."}])},50645,function(a){a.n(a.i(27572))}];

//# sourceMappingURL=src_app_layout_tsx_0r5yz5t._.js.map