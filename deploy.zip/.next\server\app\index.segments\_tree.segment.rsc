:HL["/_next/static/chunks/2pgmt8gs9didv.css","style"]
:HL["/hero_architecture.jpg","image"]
:HL["/parshuramhomestay.png","image"]
:HL["/nextap.png","image"]
:HL["/contact_banner.png","image"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"TCjnQRhCzTgXfeiQSLP4R"}
